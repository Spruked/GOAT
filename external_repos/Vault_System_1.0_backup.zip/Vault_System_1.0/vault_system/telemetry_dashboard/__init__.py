# telemetry_dashboard/__init__.py

from .telemetry_dashboard import TelemetryDashboard

__all__ = ["TelemetryDashboard"]