---
name: Security Vulnerability
about: Report a security vulnerability
title: '[SECURITY] '
labels: security
assignees: ''

---

## 🔒 Security Vulnerability Report

**Please do not report security vulnerabilities through public GitHub issues.**

## 📞 Contact Information
Please provide a way for us to contact you securely:
- Email: [your-email@example.com]
- Preferred contact method: [email/chat/etc.]

## 🚨 Vulnerability Details

### Summary
Brief description of the security vulnerability.

### Impact
What could an attacker achieve by exploiting this vulnerability?
- [ ] Data exposure
- [ ] System compromise
- [ ] Denial of service
- [ ] Authentication bypass
- [ ] Other: __________

### Affected Components
Which parts of the system are affected?
- [ ] Core vault encryption
- [ ] Authentication system
- [ ] Network interfaces
- [ ] Memory vaults
- [ ] Seed vaults
- [ ] Telemetry dashboard
- [ ] Other: __________

### Steps to Reproduce
Provide detailed steps to reproduce the vulnerability. **Do not include actual exploits in public issues.**

### Proof of Concept
If available, describe how you've verified this vulnerability exists.

### Mitigation
Any immediate workarounds or mitigations you've identified.

## 📋 Additional Information
Any other relevant information about the vulnerability.

---

**Thank you for helping keep Caleon's consciousness secure!** 🛡️